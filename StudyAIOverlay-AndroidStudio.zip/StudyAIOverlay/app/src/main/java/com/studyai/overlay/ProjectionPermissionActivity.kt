package com.studyai.overlay

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

class ProjectionPermissionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; startActivityForResult(mgr.createScreenCaptureIntent(), 99) }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==99 && resultCode==RESULT_OK && data!=null){ startService(Intent(this,OverlayService::class.java).setAction(OverlayService.ACTION_SET_PROJECTION).putExtra(OverlayService.EXTRA_RESULT,resultCode).putExtra(OverlayService.EXTRA_DATA,data)); }; finish() }
}
