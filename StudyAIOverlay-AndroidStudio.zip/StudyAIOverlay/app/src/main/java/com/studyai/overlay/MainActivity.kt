package com.studyai.overlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var endpoint: EditText
    private lateinit var model: EditText
    private lateinit var key: EditText
    private val prefs by lazy { getSharedPreferences("config", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText)
        endpoint = findViewById(R.id.endpointEdit)
        model = findViewById(R.id.modelEdit)
        key = findViewById(R.id.keyEdit)
        endpoint.setText(prefs.getString("endpoint", ""))
        model.setText(prefs.getString("model", ""))
        key.setText(prefs.getString("key", ""))

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            prefs.edit().putString("endpoint", endpoint.text.toString().trim())
                .putString("model", model.text.toString().trim())
                .putString("key", key.text.toString()).apply()
            Toast.makeText(this, "Config saved", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.startButton).setOnClickListener { startOverlay() }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val intent = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START)
        startForegroundService(intent)
        status.text = "AI ACTIVE"
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized && Settings.canDrawOverlays(this)) status.text = "AI READY"
    }
}
