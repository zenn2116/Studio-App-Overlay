package com.studyai.overlay

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class AiManager(context: Context) {
    private val prefs = context.getSharedPreferences("config", Context.MODE_PRIVATE)
    private val client = OkHttpClient()
    fun answer(question: String): String {
        val endpoint = prefs.getString("endpoint", "")?.trim().orEmpty()
        val key = prefs.getString("key", "").orEmpty()
        val model = prefs.getString("model", "")?.trim().orEmpty()
        require(endpoint.isNotBlank()) { "AI endpoint belum dikonfigurasi" }
        val prompt = "Jawab soal berikut untuk latihan. Berikan hanya pilihan dan jawaban dalam format:\nC.) HATI\nJangan memberikan penjelasan panjang. Jika soal tidak jelas, katakan TIDAK TERBACA.\n\nSoal:\n$question"
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject().put("messages", messages)
        if (model.isNotBlank()) body.put("model", model)
        val request = Request.Builder().url(endpoint).post(body.toString().toRequestBody("application/json".toMediaType())).apply {
            if (key.isNotBlank()) header("Authorization", "Bearer $key")
        }.build()
        client.newCall(request).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            val text = r.body?.string().orEmpty()
            val json = JSONObject(text)
            val choices = json.optJSONArray("choices") ?: error("Format respons AI tidak dikenali")
            if (choices.length() == 0) error("Respons AI kosong")
            return choices.getJSONObject(0).optJSONObject("message")?.optString("content").orEmpty().trim().ifBlank { "TIDAK TERBACA" }
        }
    }
}
