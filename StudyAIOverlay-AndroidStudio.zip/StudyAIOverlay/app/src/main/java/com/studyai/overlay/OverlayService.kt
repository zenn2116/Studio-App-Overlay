package com.studyai.overlay

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.*
import kotlinx.coroutines.*

class OverlayService : Service() {
    companion object { const val ACTION_START = "START"; const val ACTION_CAPTURE = "CAPTURE"; const val ACTION_STOP = "STOP"; const val ACTION_SET_PROJECTION = "SET_PROJECTION"; const val EXTRA_RESULT = "RESULT"; const val EXTRA_DATA = "DATA" }
    private lateinit var wm: WindowManager
    private lateinit var panel: LinearLayout
    private lateinit var result: TextView
    private lateinit var status: TextView
    private var capture: ScreenCaptureManager? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager; createNotification(); showPanel() }
    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        when (i?.action) {
            ACTION_SET_PROJECTION -> { capture = ScreenCaptureManager(this); capture!!.setProjection(i.getIntExtra(EXTRA_RESULT, Activity.RESULT_CANCELED), i.getParcelableExtra(EXTRA_DATA)!!); status.text = "READY TO SCAN" }
            ACTION_CAPTURE -> scan()
            ACTION_STOP -> stopSelf()
        }; return START_STICKY
    }

    private fun showPanel() {
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,18,18,18); setBackgroundColor(Color.rgb(17,23,21)) }
        val title = TextView(this).apply { text="AI ANSWER"; textSize=18f; setTextColor(Color.rgb(25,216,137)); setTypeface(null,1) }
        status = TextView(this).apply { text="READY TO SCAN"; textSize=12f; setTextColor(Color.LTGRAY) }
        result = TextView(this).apply { text="Tekan SCAN SOAL"; textSize=18f; setTextColor(Color.WHITE); setPadding(0,16,0,16) }
        val scan = Button(this).apply { text="SCAN SOAL"; setOnClickListener { scan() } }
        val close = Button(this).apply { text="TUTUP"; setOnClickListener { stopSelf() } }
        panel.addView(title); panel.addView(status); panel.addView(result); panel.addView(scan); panel.addView(close)
        panel.setOnTouchListener(DragTouchListener())
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val p = WindowManager.LayoutParams(360, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=30; y=160 }
        wm.addView(panel,p)
    }

    private fun scan() {
        if (capture == null) { requestProjection(); return }
        scope.launch {
            try {
                status.text="Scanning..."; delay(300); status.text="Reading..."
                val bmp = withContext(Dispatchers.Default) { capture!!.capture() }
                val text = withContext(Dispatchers.Default) { OcrManager().read(bmp) }
                if (text.isBlank()) { result.text="Teks soal tidak terbaca. Coba scan lagi."; status.text="OCR FAILED"; return@launch }
                status.text="AI Processing..."
                val answer = withContext(Dispatchers.IO) { AiManager(this@OverlayService).answer(text) }
                result.text=answer; status.text="AI ANSWER"
            } catch (e: Exception) { result.text = if (e.message?.contains("endpoint", true)==true) "AI tidak dapat memproses soal." else "Teks soal tidak terbaca. Coba scan lagi."; status.text="ERROR" }
        }
    }

    private fun requestProjection() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        val pi = PendingIntent.getActivity(this, 22, Intent(this, MainActivity::class.java).setAction("PROJECTION_RESULT"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        // Launch the system consent UI from a transparent activity instead; service itself cannot request it.
        val i = Intent(this, ProjectionPermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun createNotification() {
        val channel="study_overlay"
        val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(channel,"Study AI Overlay",NotificationManager.IMPORTANCE_LOW))
        val n=Notification.Builder(this,channel).setContentTitle("Study AI Overlay").setContentText("Overlay aktif").setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT>=29) startForeground(7,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(7,n)
    }
    override fun onDestroy(){ scope.cancel(); if(::panel.isInitialized) wm.removeView(panel); capture?.stop(); super.onDestroy() }
    override fun onBind(i: Intent?)=null

    private inner class DragTouchListener: View.OnTouchListener { var sx=0f; var sy=0f; var ox=0; var oy=0; override fun onTouch(v:View,e:android.view.MotionEvent):Boolean { val lp=panel.layoutParams as WindowManager.LayoutParams; when(e.action){0-> {sx=e.rawX;sy=e.rawY;ox=lp.x;oy=lp.y};2->{lp.x=ox+(e.rawX-sx).toInt();lp.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(panel,lp)} }; return true } }
}
