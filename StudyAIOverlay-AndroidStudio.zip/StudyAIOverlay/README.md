# Study AI Overlay

Android Studio project for a real floating study assistant.

## What is implemented
- Kotlin, min SDK 26, target SDK 35
- SYSTEM_ALERT_WINDOW + TYPE_APPLICATION_OVERLAY
- Foreground service with MediaProjection
- Real screen capture using ImageReader/VirtualDisplay
- Google ML Kit Text Recognition
- Configurable OpenAI-compatible AI endpoint/model/key (no key hard-coded)
- Draggable overlay
- No auto-click, auto-submit, or form filling

## Build
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).

## Important
For Android 14+, MediaProjection requires explicit user consent and foreground-service mediaProjection handling. The app only captures after the user approves the system capture dialog.
